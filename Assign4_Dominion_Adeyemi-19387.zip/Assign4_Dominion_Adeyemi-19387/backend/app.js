const express = require('express');
const app = express();
const port = 3000; // Choose a port number
const path = require('path');


// Middleware to parse JSON and form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (CSS, images, etc.) from a directory
app.use(express.static(path.join(__dirname, '../frontend/public')));


// Handle GET request for the root URL ('/')
app.get('/', (req, res) => {
    
    const filePath = path.join(__dirname, '../frontend/public/assign3.html');

    // Send the file as a response
    res.sendFile(filePath);
});


// Handle POST request to calculate total amount
app.post('/submit-order', (req, res) => {
    // Process form data from req.body to calculate total amount
    const { items } = req.body; // Assuming items is an array of selected items
    let subtotal = 0;

    // Calculate subtotal based on items received
    items.forEach(item => {
        subtotal += item.price * item.quantity;
    });

    const taxRate = 0.0825;
    const tax = subtotal * taxRate;
    const total = subtotal + tax;

    // Redirect to confirmation page with order details as query parameters
    res.redirect(`/confirmation.html?subtotal=${subtotal}&tax=${tax}&total=${total}`);
});

app.get('/confirmation', (req, res) => {
    const { subtotal, tax, total } = req.query;
    res.sendFile(path.join(__dirname, 'public', 'confirmation.html'));
});


// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});

