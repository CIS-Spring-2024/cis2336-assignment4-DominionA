// confirmation.js

document.addEventListener("DOMContentLoaded", function() {
    const urlParams = new URLSearchParams(window.location.search);
    const subtotal = urlParams.get('subtotal');
    const tax = urlParams.get('tax');
    const total = urlParams.get('total');

    document.getElementById('subtotal').textContent = subtotal;
    document.getElementById('tax').textContent = tax;
    document.getElementById('total').textContent = total;
});
